package ir.ac.sbu.syntax;

public interface CodeGenerator {
    void doSemantic(String sem);
}