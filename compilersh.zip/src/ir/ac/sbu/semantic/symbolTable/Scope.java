package ir.ac.sbu.semantic.symbolTable;

public enum Scope {
    FUNCTION,
    LOOP,
    SWITCH,
    IF,
    GLOBAL
}
