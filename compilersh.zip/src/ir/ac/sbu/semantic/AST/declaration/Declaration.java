package ir.ac.sbu.semantic.AST.declaration;

import ir.ac.sbu.semantic.AST.Node;

public interface Declaration extends Node {
}
