package ir.ac.sbu.semantic.AST;

public interface Operation extends Node {
}
