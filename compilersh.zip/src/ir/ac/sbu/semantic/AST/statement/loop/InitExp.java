package ir.ac.sbu.semantic.AST.statement.loop;

import ir.ac.sbu.semantic.AST.Node;

public interface InitExp extends Node{
}
