package syntax;

public interface CodeGenerator {
    void doSemantic(String sem);
}