package semantic.AST.statement.loop;

import semantic.AST.Node;

public interface InitExp extends Node{
}
