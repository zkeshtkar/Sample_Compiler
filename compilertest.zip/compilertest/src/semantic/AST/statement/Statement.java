package semantic.AST.statement;

import semantic.AST.Operation;
import lombok.Data;

@Data
public abstract class Statement implements Operation {
}
