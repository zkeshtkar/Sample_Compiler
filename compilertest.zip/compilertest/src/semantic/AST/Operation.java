package semantic.AST;

public interface Operation extends Node {
}
