package semantic.AST.expression.variable;

import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.MethodVisitor;

public class RecordVar extends Variable {
    @Override
    public void codegen(MethodVisitor mv, ClassWriter cw) {
    }
}
