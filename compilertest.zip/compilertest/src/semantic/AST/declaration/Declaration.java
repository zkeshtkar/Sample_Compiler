package semantic.AST.declaration;

import semantic.AST.Node;

public interface Declaration extends Node {
}
