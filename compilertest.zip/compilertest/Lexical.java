public interface Lexical {
    String nextToken();
}